package Response;

import model.UserProfile;

public interface IResponse {
    public void doAction(UserProfile profile) ;
}
