package Response;

import SmartBoard.UserProfile;

public interface IResponse {
    public void doAction(UserProfile profile) ;
}
